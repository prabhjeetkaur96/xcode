//
//  main.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let dataHelper = DataHelper()

var sourcechoice:Int = 0
var destinationchoice:Int = 0

func displaySourceCountry() {
    
    print("Select Source")
    print("Enter 1 For Canada")
    print("Enter 2 For Uganda")
    print("Enter 3 For Syria")
    print("Enter 4 for Pakistan")
    print("Enter choice : ")
    sourcechoice = Int(readLine()!)!
    print(sourcechoice)
}

func displayDestCountry()  {
    print("Select Destination")
    print("Enter 1 For Uganda")
    print("Enter 2 For Syria")
    print("Enter 3 For Pakistan")
    print("Enter 4 for Canada")
    print("Enter choice : ")
    destinationchoice = Int(readLine()!)!
    print(destinationchoice)
}



var choice = 10
while(choice != 7) {
print("\nPress 1 For Employee Details")
print("Press 2 For Input Passenger Details : ")
print("Press 3 For Airline Information")
print("Press 4 For Flight ")
print("Enter 7 to Exit")
print("Enter Choice : ")
choice = Int(readLine()!)!
    let prabhjeet = Passenger()

    
switch choice {
case 1 :
      dataHelper.displayEmployee()
    break
case 2 :
    prabhjeet.addPassenger()
print(prabhjeet.displayData())
    
    break
case 3 :
    //dataHelper.displayAirline()
    break
case 4:
    displaySourceCountry()
    displayDestCountry()
    print("Available Flights")
    dataHelper.displayFlight()
   break
case 5 :
   break
    
case 7 :
    exit(0)
default :
    print("Please Enter Right Choice")
}
}







