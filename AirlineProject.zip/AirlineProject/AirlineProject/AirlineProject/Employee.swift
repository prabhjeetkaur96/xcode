//
//  Employee.swift
//  AirlineProject
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Employee: IDisplay {
    
    private var employeeID : Int?
    private var employeeName : String?
    private var address : String?
    private var email : String?
    private var designation : String?
    private var mobile : String?
    
    
    init(){
        self.employeeID = 0
        self.employeeName = ""
        self.address = ""
        self.email = ""
        self.designation = ""
        self.mobile = ""
    }
    
    init(employeeID: Int, employeeName: String, address: String, email: String, designation: String, mobile: String){
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.address = address
        self.email = email
        self.designation = designation
        self.mobile = mobile
    }
    
    
    var EmployeeID : Int? {
        get{ return self.employeeID}
        set{ self.employeeID = newValue}
    }
    var EmployeeName : String?{
        get{return self.employeeName}
        set{self.employeeName = newValue}
    }
    var Address : String?{
        get{return self.address}
        set{self.address = newValue}
    }
    var Email : String?{
        get{return self.email}
        set{self.email = newValue}
    }
    var Designation : String?{
        get{return self.designation}
        set{self.designation = newValue}
    }
    var Mobile : String?{
        get{return self.mobile}
        set{self.mobile = newValue}
    }
    
    
    
    
    func displayData() -> String{
        var returnData = ""
        
        if self.employeeID != nil {
            returnData += "\n Employee ID : \(self.employeeID ?? 0)"
        }
        
        if self.employeeName != nil {
            returnData += "\n Employee Name : \(self.employeeName ?? "Unknown")"
        }
        if self.address != nil {
            returnData += "\n  Address : \(self.address ?? "Unknown")"
        }
        if self.email != nil {
            returnData += "\n Email : \(self.email ?? "email@mad.com")"
        }
        if self.designation != nil {
            returnData += "\n Designation : \(self.designation ?? "Unknown")"
        }
        if self.mobile != nil {
            returnData += "\n Employeee Mobile : \(self.mobile ?? "") \n"
        }
        return returnData
    }
    
    func registerUser(){
        print("Enter Employee ID : ")
        self.employeeID = (Int)(readLine()!)
        print("Enter Employee Name : ")
        self.employeeName = readLine()!
        print("Enter  Address : ")
        self.address = readLine()!
        print("Enter Email : ")
        self.email = readLine()!
        print("Enter Designation : ")
        self.designation = readLine()!
        print("Enter Employeee Mobile : ")
        self.mobile = readLine()!
        
    }
    
    
    
    
}
