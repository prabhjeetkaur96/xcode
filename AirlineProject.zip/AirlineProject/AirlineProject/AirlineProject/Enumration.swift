//
//  Enumration.swift
//  AirlineProject
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

enum cityList : Int, CaseIterable
{
    case Canada = 1
    case Uganda = 2
    case Syria = 3
    case Pakistan = 4
    case India = 5
    case China = 6
    case USA = 7
    case Australia = 8
    case None = 9
}

extension CaseIterable where Self: Hashable {
    static var allCases: [Self] {
        return [Self](AnySequence { () -> AnyIterator<Self> in
            var raw = 0
            var first: Self?
            return AnyIterator {
                let current = withUnsafeBytes(of: &raw) { $0.load(as: Self.self) }
                if raw == 0 {
                    first = current
                } else if current == first {
                    return nil
                }
                raw += 1
                return current
            }
        })
    }
}
