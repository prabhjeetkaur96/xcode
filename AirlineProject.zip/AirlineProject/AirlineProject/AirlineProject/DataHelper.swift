//
//  DataHelper.swift
//  AirlineProject
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var AirlineList = [Int: Airline]()
    var EmployeeList = [Int : Employee]()
    var FlightList = [String : Flight]()
    
    init(){
        self.loadAirlineData()
        self.loadEmployeeData()
        self.loadFlightData()
    }
    
    func loadAirlineData(){
        AirlineList = [:]
        
        let Alitalia = Airline(airlineID : 111, airlineDescription : "Italian airline" , airlineType : "International" )
        AirlineList[Alitalia.AirlineID!] = Alitalia
        
        let AirCanada = Airline(airlineID : 202, airlineDescription : " Canadian airline" , airlineType : "International" )
        AirlineList[AirCanada.AirlineID!] = AirCanada
        
        let Etihad = Airline(airlineID : 333, airlineDescription : "Most Expensive airline" , airlineType : "International" )
        AirlineList[Etihad.AirlineID!] = Etihad
        
        let JetAirways = Airline(airlineID : 404, airlineDescription : "Common airline" , airlineType: "National" )
        AirlineList[JetAirways.AirlineID!] = JetAirways
        
        let CathayPacific = Airline(airlineID : 505, airlineDescription : "Prefferable airline" , airlineType : "International"  )
        AirlineList[CathayPacific.AirlineID!] = CathayPacific    }
    
    
    func displayAirline(){
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key} ){
            Util.drawLine()
            print(value.displayData())
        }}
    
    func loadEmployeeData(){
        EmployeeList = [:]
        
        let Aman = Employee(employeeID : 101, employeeName: "Aman",address: "114 Michigan Ave. Brampton", email: "param@mad.com", designation: "Pilot", mobile :"9876878976")
        EmployeeList[Aman.EmployeeID!] = Aman
        
        let Jatinder = Employee(employeeID : 102, employeeName: "Jatinder",address: "203 Herkes Dr. Brampton", email: "Jatinder@mad.com", designation: "Crew Member", mobile :"6574657865")
        EmployeeList[Jatinder.EmployeeID!] = Jatinder
    }
    
    func displayEmployee(){
        for (_, value) in self.EmployeeList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
    }
    
    
    func loadFlightData(){
        FlightList = [:]
        do{
            let jtnder = try Flight(flightID: "111", flightFrom: cityList.Canada, flightTo: cityList.India, flightScheduleDate: "23/07/2018", price : 1300.45)
            FlightList[jtnder.flightID!] = jtnder
            
            let prabh = try Flight(flightID: "112", flightFrom: cityList.Pakistan, flightTo: cityList.USA, flightScheduleDate: "30/07/2018", price :  1400.45)
            FlightList[prabh.flightID!] = prabh
            
            let preet = try Flight(flightID: "113", flightFrom: cityList.Uganda, flightTo: cityList.China, flightScheduleDate: "30/07/2018", price :  1500.45)
            FlightList[preet.flightID!] = preet
            
            let jtnder2 = try Flight(flightID: "114", flightFrom: cityList.Syria, flightTo: cityList.China, flightScheduleDate: "23/07/2018", price :  1100.45)
            FlightList[jtnder2.flightID!] = jtnder2
            
            let prabh2 = try Flight(flightID: "115", flightFrom: cityList.Canada, flightTo: cityList.Australia, flightScheduleDate: "30/07/2018", price :  2000.45)
            FlightList[prabh2.flightID!] = prabh2
            
            let preet2 = try Flight(flightID: "116", flightFrom: cityList.Pakistan, flightTo: cityList.India, flightScheduleDate: "30/07/2018", price :   400.45)
            FlightList[preet2.flightID!] = preet2        }catch{
                print("Error: \(error)")
        }}
    func displayFlight(){
        for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
    }
    func searchFlight(flightID : String) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry.. no seats are available ")
            return nil
        }
    }
}
