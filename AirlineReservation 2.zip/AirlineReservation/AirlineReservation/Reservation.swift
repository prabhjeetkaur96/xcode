//
//  Reservation.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation : Passenger {
    var reservationID : Int?
    private var description : String?
    private var seatNumber : String?
    private var status : String?
    private var mealType : String?
    
    
    
    
    
    var ReservationID :Int?{
        get{ return self.reservationID}
        set{ self.reservationID = newValue }
    }
    
    var Description: String?{
        get{ return self.description }
        set{ self.description = newValue }
    }
    
    
   
    var SeatNumber : String?{
        get { return self.seatNumber}
        set {self.seatNumber = newValue}
    }
    var Status : String?{
        get { return self.status}
        set {self.status = newValue}
    }
    var MealType : String?{
        get { return self.mealType}
        set {self.mealType = newValue}
    }
    
    
     override init(){
        self.reservationID = 0
        self.description = ""
        
        self.seatNumber = ""
        self.status = ""
        self.mealType = ""
        super.init()
    }
    
   
    required init(reservationID: Int, description : String, passengerId : Int ,seatNumber : String, status : String , mealType : String){
       super.init()
        self.reservationID = reservationID
        self.description = description
       
        self.seatNumber = seatNumber
        self.status = status
        self.mealType = mealType
}
    
    override func displayData() -> String{
        super.displayData()
        var returnData = ""
        
        if self.reservationID != nil{
            returnData += "\n Reservation Id: \(self.reservationID ?? 0)"
        }
        if self.description != nil{
            returnData += "\n Description:" +  self.description!
        }
       
        if self.seatNumber != nil{
            returnData += "\n Seat Number:" +  self.seatNumber!
        }
        if self.status != nil{
            returnData += "\n Status:" +  self.status!
        }
        if self.mealType != nil{
            returnData += "\n Meal Type:" +  self.mealType!
        }
        return returnData
    }
    }
