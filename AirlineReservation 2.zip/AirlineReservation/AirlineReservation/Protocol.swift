//
//  Protocol.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


protocol IDisplay{
    func displayData() -> String
}
