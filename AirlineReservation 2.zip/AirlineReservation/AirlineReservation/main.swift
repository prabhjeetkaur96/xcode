//
//  main.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let dataHelper = DataHelper()

var choice = 10
while(choice != 7) {
print("\nPress 1 For Employee Details")
print("Press 2 For Input Passenger Details : ")
print("Press 3 For Airline Information")
print("Enter 7 to Exit")
print("Enter Choice : ")
choice = Int(readLine()!)!
    
    let prabhjeet = Passenger()
    
switch choice {
case 1 :
      dataHelper.displayEmployee()
    break
case 2 :
    prabhjeet.addPassenger()
print(prabhjeet.displayData())
    
    break
case 3 :
    dataHelper.displayAirline()
    break
case 7 :
    exit(0)
default :
    print("Please Enter Right Choice")
}
}







