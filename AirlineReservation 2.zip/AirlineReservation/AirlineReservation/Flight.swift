//
//  Flight.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    
    private var flightID : String?
    
    private var flightFrom : String?
    
    private var flightTo : String?
    
    private var flightScheduleDate : String?
    
    private var flightAirlineId : Int?
    
    private var flightAirplaneId : String?
    

    
    
    
    var FlightID : String?{
        get{
            return self.flightID
        }
        set{
            self.flightID = newValue
        }
    }
        var FlightFrom : String?{
        get{
        return self.flightFrom
        }
        set{
        self.flightFrom = newValue
            }}
    
    var FlightTo : String?{
        get{
            return self.flightTo
        }
        set{
            self.flightTo = newValue
        }}
    
    var FlightScheduleDate: String?{
        get{
            return self.flightScheduleDate
        }
        set{
            self.flightScheduleDate = newValue
        }}
    
    var FlightAirlineId: Int?{
        get{
            return self.flightAirlineId
        }
        set{
            self.flightAirlineId = newValue
        }}
    
    var FlightAirplaneId: String?{
        get{
            return self.flightAirplaneId
        }
        set{
            self.flightAirplaneId = newValue
        }}
    
    init(){
        self.flightID = ""
        
        self.flightFrom = ""
        
        self.flightTo = ""
        
        self.flightScheduleDate = ""
        
        self.flightAirlineId = 0
        
        self.flightAirplaneId =  ""
        
        
    }
    
    init(flightID : String , flightFrom : String, flightTo: String, flightScheduleDate : String , flightAirlineId : Int , flightAirplaneId : String){
        
        self.flightID = flightID
        
        self.flightFrom = flightFrom
        
        self.flightTo = flightTo
        
        self.flightScheduleDate = flightScheduleDate
        
        self.flightAirlineId = flightAirlineId
        
        self.flightAirplaneId = flightAirplaneId
      
        
    }
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.flightID != nil{
            
            returnData += "\n Flight Id: \(self.flightID ?? "")"
            
        }
        
        if self.flightFrom != nil{
            
            returnData += "\n Flight From : " + self.flightFrom!
            
        }
        
        if self.flightTo != nil{
            
            returnData += "\n Flight To : " + self.flightTo!
        }
        
        if self.flightScheduleDate != nil{
            
            returnData += "\n  Flight Schedule Date :" + self.flightScheduleDate!
        }
        
        if self.flightAirlineId != nil{
            
            returnData += "\n  Flight Airline Id :  \(self.flightAirlineId ?? 0)"
        }
        
        
        if self.flightAirplaneId != nil{
            
            returnData += "\n  Flight Airplane id :" + self.flightAirplaneId!
        }
        
        return returnData
        
    }}
