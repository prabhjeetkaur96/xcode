//
//  Flight.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    
   var flightID :String?
    
    private var flightFrom :cityList
    
    private var flightTo : cityList
    
    private var flightScheduleDate : String?
    
     var price : Double?

    
    
    
     public var FlightID : String?{
        get{
            return self.flightID
        }
        set{
            self.flightID = newValue
        }
    }
        var FlightFrom : cityList{
        get{
        return self.flightFrom
        }
        set{
        self.flightFrom = newValue
            }}
    
    var FlightTo : cityList{
        get{
            return self.flightTo
        }
        set{
            self.flightTo = newValue
        }}
    
    var FlightScheduleDate: String?{
        get{
            return self.flightScheduleDate
        }
        set{
            self.flightScheduleDate = newValue
        }}
    
    var Price : Double{
        get{
            return self.price!
        }
        set{
            self.price = newValue
        }}
    
    init(){
        self.flightID = ""
        
        self.flightFrom = cityList.None
        
        self.flightTo = cityList.None
        
        self.flightScheduleDate = ""
        
       self.price = 0.0
        
    }
    
    init(flightID : String , flightFrom : cityList, flightTo: cityList, flightScheduleDate : String ,price : Double){
        
        self.flightID = flightID
        
        self.flightFrom = flightFrom
        
        self.flightTo = flightTo
        
        self.flightScheduleDate = flightScheduleDate
       
        self.price = price
    }
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.flightID != nil{
            
            returnData += "\n Flight Id: \(self.flightID ?? "")"
            
        }
        
        if self.flightFrom != nil{
            
            returnData += "\n Flight From : \(self.flightFrom ?? cityList.None) "
            
        }
        
        if self.flightTo != nil{
            
            returnData += "\n Flight To :  \(self.flightTo ?? cityList.None)  "
        }
        
        if self.flightScheduleDate != nil{
            
            returnData += "\n  Flight Schedule Date :" + self.flightScheduleDate!
        }
        
        if self.price != nil{
            
            returnData += "\n  Flight price: $  \(self.price ?? 0.0)"
            
        }
        
        return returnData
        
    }}
