//
//  Reservation.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
typealias FlightItem = (flightID: String, flight: Flight,quantity: Int)

class Reservation : Passenger {
    
    var reservationID : String?
    private var description : String?
    private var seatNumber : String?
    private var mealType : String?
    private var availableSeat : Int?
     private var flightBooked: [FlightItem]
    
    
    
    var ReservationID :String?{
        get{ return self.reservationID}
        set{ self.reservationID = newValue }
    }
    
    var Description: String?{
        get{ return self.description }
        set{ self.description = newValue }
    }
    
    
   
    var SeatNumber : String?{
        get { return self.seatNumber}
        set {self.seatNumber = newValue}
    }

    var MealType : String?{
        get { return self.mealType}
        set {self.mealType = newValue}
    }
    var AvailableSeat : Int?{
        get { return self.availableSeat}
        set {self.availableSeat = newValue}
    }
    
    var RevAmount: Double?{
        get{
            var amount = 0.0
            if !self.flightBooked.isEmpty{
                for (_, prod, qty) in self.flightBooked{
                    amount += prod.price! * (Double)(qty)
                }
            }
            return amount
        }
    }
    
    override init(){
        self.reservationID = ""
        self.description = "Economy"
        self.seatNumber = "A3"
        self.mealType = ""
        self.availableSeat = 0
        self.flightBooked = []
        super.init()
    }
    
   
//    required init(reservationID: Int, description : String, passengerId : Int ,seatNumber : String, status : String , mealType : String, availableSeat: Int,passportNumber: String, name: String ,address: String,email: String,mobile: String,date_of_birth: String){
//       super.init()
//        self.reservationID = reservationID
//        self.description = description
//        self.seatNumber = seatNumber
//        self.status = status
//        self.mealType = mealType
//        self.availableSeat = availableSeat
//        self.flightBooked = FlightItem
//    }
    
    
   
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Reservation ID : \(self.reservationID!)"
        returnData += "\n Description : \(self.description! )"
        returnData += "\n Seat Number : \(self.seatNumber!)"
        returnData += "\n Meal Type : \(self.mealType!)"
        returnData += "\n Available seats : \(self.availableSeat!)"
        
        returnData += "\n Flight Booked : "
        if !self.flightBooked.isEmpty{
            for (_, flight,  qty) in self.flightBooked{
                returnData += "\n \t Flight: \(flight.displayData())"
                returnData += "\n \tQuantity : \(qty)"
            }
        }else{
            returnData += "\n No seat Available"
        }
    
        returnData += "\n  Amount : \(self.RevAmount  ?? 0.0)"
        
        return returnData
    }
    
    func addReservation()
    {
        print("Enter Meal Type : ")
        self.mealType = readLine()!
    }
    
    
    func addOrder(){
        dataHelper.displayFlight()
        print("Please enter Flight ID to choose any Flight from the list : ")
        let selectedFlightID : String = (readLine()!)
        
        if let selectedFlight = dataHelper.searchFlight(flightID: selectedFlightID){
            self.reservationID = selectedFlightID
           
            
            print("How many seats do you want ? : ")
            let qty : Int = (Int)(readLine()!) ?? 1
            if qty > 4{
                print("Sorry...... We are out of seats ")
            }
            self.flightBooked += [(flightID: selectedFlightID, flight: selectedFlight, quantity: qty)]
          
            
        }else{
            print("Sorry...seats are not available")
        }
    }
    
    func cancelOrder(){
        if !flightBooked.isEmpty {
            print("Review your Seat \n \(self.displayData())")
            
            print("Please enter Flight ID to remove from the Reservation : ")
            let selectedFlightID : String = (readLine()!)
            var FlightIndex = -1
            
            for (index, item) in self.flightBooked.enumerated(){
                if (item.flightID == selectedFlightID){
                   FlightIndex = index
                }
            }
            
            if FlightIndex != -1{
                self.flightBooked.remove(at: FlightIndex)
                print("The  seat is removed from your reservation")
            }
        }else{
            print("You have no  selected seat in your  reservation")
        }
    }
}


