//
//  main.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let dataHelper = DataHelper()
var reservation = Reservation()
var sourcechoice:Int = 0
var destinationchoice:Int = 0

func displaySourceCountry() {
    
    print("Select Source")
    print("Enter 1 For Canada")
    print("Enter 2 For Uganda")
    print("Enter 3 For Syria")
    print("Enter 4 for Pakistan")
    print("Enter choice : ")
    sourcechoice = Int(readLine()!)!
    print(sourcechoice)
}

func displayDestCountry()  {
    print("Select Destination")
    print("Enter 1 For India")
    print("Enter 2 For China")
    print("Enter 3 For USA")
    print("Enter 4 for Australia")
    print("Enter choice : ")
    destinationchoice = Int(readLine()!)!
    print(destinationchoice)
}



var choice = 10
while(choice != 7) {
    print("\nPress 1 For Employee Details ")
    print("Press 2 For Input Passenger Details ")
    print("Press 3 For Flight ")
    print("Press 4 For Reservation  ")
    print("Press 5 For Display Seat Reservation ")
    print("Press 6 For Cancel  Reservation ")
    print("Enter 7 to Exit ")
    print("Enter Choice : ")
choice = Int(readLine()!)!
    let prabhjeet = Passenger()
    
switch choice {
case 1 :
      dataHelper.displayEmployee()
    break
case 2 :
    prabhjeet.addPassenger()
print(prabhjeet.displayData())
    
    break
case 3 :
    displaySourceCountry()
    displayDestCountry()
    print("Available Flights")
    dataHelper.displayFlight()
   break
case 4 :
    reservation.addOrder()
    reservation.addReservation()
   break
case 5 :
     print(reservation.displayData())
    break
case 6:
    reservation.cancelOrder()
    break
case 7 :
    exit(0)
default :
    print("Please Enter Right Choice")
}
}







