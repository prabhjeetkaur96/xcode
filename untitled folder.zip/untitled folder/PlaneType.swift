//
//  PlaneType.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PlaneType{
    
    
    
    var planeTypeId : String?
    private var planeTypeTotalSeats : Int?
    private var planeTypeSeatmap : String?
    
    
    var PlaneTypeTotalSeats : Int?{
        
        get{
            return self.planeTypeTotalSeats
         }
        set{
            self.planeTypeTotalSeats = newValue
            
    }
    }

    var PlaneTypeSeatmap : String?{
        
        get{
            return self.planeTypeSeatmap
            }
        set{
            self.planeTypeSeatmap = newValue
            }
        
    }
    
    init(){
        
        self.planeTypeId = ""
        self.planeTypeTotalSeats = 0
        self.planeTypeSeatmap = ""
        
    }
    
    init( planeTypeId : String,  planeTypeTotalSeats : Int, planeTypeSeatmap : String){
    
        self.planeTypeId = planeTypeId
        self.planeTypeTotalSeats = planeTypeTotalSeats
        self.planeTypeSeatmap = planeTypeSeatmap
        
    }

    func addPlaneTYpe(){
        
        print("Enter plane type Id : ")
        self.planeTypeId = readLine()!
        
        print("Enter plane Type Total Seats : ")
        self.planeTypeTotalSeats = (Int)(readLine()!)!
        
        print("Enter plane Type Seat map  : ")
        self.planeTypeSeatmap = readLine()!
        
        
        
    }
    
}
