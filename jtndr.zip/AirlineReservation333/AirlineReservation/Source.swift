//
//  Source.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//
import Foundation


class Countries {
    
    
    
    private var sourcecountry : String?
    private var destinationcountry : String?
    
    
   
    
    var SourceCountry : String?{
        get{ return self.sourcecountry
        }
        set{self.sourcecountry = newValue}
    }
    
    var DestinationCountry : String?{
        get{ return self.destinationcountry
        }
        set{self.destinationcountry = newValue}
    }

    
    init(){
        self.sourcecountry = ""
        self.destinationcountry = ""
    
    }
    
    
    
    init(sourcecountry: String , destinationcountry : String ){
        self.sourcecountry = sourcecountry
        self.destinationcountry = destinationcountry

    }
    
    
}

