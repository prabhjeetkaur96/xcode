//
//  Flight.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    
   var flightID :String?
    
    private var flightFrom :cityList
    
    private var flightTo : cityList
    
    private var flightScheduleDate : String?
    
   

    
    
    
     public var FlightID : String?{
        get{
            return self.flightID
        }
        set{
            self.flightID = newValue
        }
    }
        var FlightFrom : cityList{
        get{
        return self.flightFrom
        }
        set{
        self.flightFrom = newValue
            }}
    
    var FlightTo : cityList{
        get{
            return self.flightTo
        }
        set{
            self.flightTo = newValue
        }}
    
    var FlightScheduleDate: String?{
        get{
            return self.flightScheduleDate
        }
        set{
            self.flightScheduleDate = newValue
        }}
    
    
    
    init(){
        self.flightID = ""
        
        self.flightFrom = cityList.None
        
        self.flightTo = cityList.None
        
        self.flightScheduleDate = ""
        
       
        
        
    }
    
    init(flightID : String , flightFrom : cityList, flightTo: cityList, flightScheduleDate : String ){
        
        self.flightID = flightID
        
        self.flightFrom = flightFrom
        
        self.flightTo = flightTo
        
        self.flightScheduleDate = flightScheduleDate
       
        
    }
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.flightID != nil{
            
            returnData += "\n Flight Id: \(self.flightID ?? "")"
            
        }
        
        if self.flightFrom != nil{
            
            returnData += "\n Flight From : \(flightFrom.rawValue) "
            
        }
        
        if self.flightTo != nil{
            
            returnData += "\n Flight To :  \(flightFrom.rawValue) "
        }
        
        if self.flightScheduleDate != nil{
            
            returnData += "\n  Flight Schedule Date :" + self.flightScheduleDate!
        }
        
        
        
        return returnData
        
    }}
